from rubpy import Client
from rubpy.types import Update
import requests as re
import json as j
import requests,random,os,time,jdatetime
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from googlesearch import search
from traceback import format_exc
import user_agants

__version__="1.1.7"

def find_mp3_links(song_name):
    query = f"آهنگ {song_name}"
    try:
        # جستجو در گوگل و دریافت اولین نتیجه
        search_results = search(query, stop=1)
        first_result = next(search_results)
        
        print(f"سایت اول در نتایج جستجو: {first_result}")
        
        # دریافت محتوای صفحه
        headers = {
            'User-Agent': random.choice(user_agants.users)
        }
        response = requests.get(first_result, headers=headers)
        response.raise_for_status()
        
        # تجزیه HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # یافتن تمام لینک‌هایی که به فایل‌های MP3 ختم می‌شوند
        mp3_links = []
        for link in soup.find_all('a', href=True):
            href = link['href']
            if href.lower().endswith('.mp3'):
                absolute_url = urljoin(first_result, href)
                mp3_links.append(absolute_url)
        
        # همچنین بررسی تگ‌های صوتی
        for audio_tag in soup.find_all('audio'):
            if audio_tag.get('src'):
                src = audio_tag.get('src')
                if src.lower().endswith('.mp3'):
                    absolute_url = urljoin(first_result, src)
                    mp3_links.append(absolute_url)
        
        return mp3_links
    
    except Exception as e:
        print(f"خطا در پردازش: {e}")
        return []

try:
    with open("datas.json","r",encoding="utf-8") as file:
        datas=j.load(file)
except:
    with open("datas.json","w",encoding="utf-8") as file:
        file.write("{}")
        datas={}

def save_datas():
    with open("datas.json","w",encoding="utf-8") as file:
        j.dump(datas, file, ensure_ascii=False, indent=4)




try:
    with open("ab_group.json","r",encoding="utf-8") as file:
        ab_group=j.load(file)
except:
    with open("ab_group.json","w",encoding="utf-8") as file:
        file.write("{}")
        ab_group={}

def save_ab_group():
    with open("ab_group.json","w",encoding="utf-8") as file:
        j.dump(ab_group, file, ensure_ascii=False, indent=4)
    


def timestamp_to_shamsi(timestamp):
    datetime_obj = jdatetime.datetime.fromtimestamp(timestamp)
    shamsi_date = datetime_obj.strftime("%Y/%m/%d")
    return shamsi_date

def days_between_shamsi_dates(date1_str, date2_str):
    date1 = jdatetime.datetime.strptime(date1_str, "%Y/%m/%d")
    date2 = jdatetime.datetime.strptime(date2_str, "%Y/%m/%d")
    days_diff = abs((date2 - date1).days)
    return days_diff


list_j=['جون؟','کوفت','مرض','بله؟','درد بی درمون 😒','باز چته 😐','یه دقیقه ولم کن 😐']

owner='u0HSsXp01f6ad623ad9000d0a3ac74ec'

bot=Client("rubpy")

help="""
🔍 **جستجوی آهنگ**  
`آهنگ {نام موسیقی}`  
مثال:  
`آهنگ لری`  
`آهنگ شور برنو سجاد رزمجو`  

🔗 **پخش از لینک مستقیم**  
`پخش ویسکال {لینک دانلود}`  
مثال:  
`پخش ویسکال [لینک مستقیم]`  

⏹ **توقف پخش**  
`قطع ویسکال`  

🔄 **پخش با ریپلای**  
ریپلای روی آهنگ + ارسال `پخش`  

🎲 **پخش تصادفی**  
`پخش رندوم`  

🔓 **مدیریت دسترسی**  
`دسترسی عموم باز` - باز کردن پخش برای همه  
`دسترسی عموم قفل` - محدود کردن پخش  

📄 **شناسه گوید**  
`گوید`

🔵 **مقام**
`مقامم`

📞 **کال**
`ساخت کال`

🔐 **وضعیت**
`وضعیت`

📊 **لیست ویژه**
`لیست ویژه`

💝 **ویژه کردن(مخصوص ادمین ها)**
`ویژه` + ریپلای
`حذف ویژه` + ریپلای
"""

@bot.on_message_updates()
async def robot(m: Update):
    group_id=m.object_guid
    MESSAGE_TEXT=m.text
    USER_GUID=m.author_guid
    if str(MESSAGE_TEXT).startswith("join ") and USER_GUID==owner:
        link_group=MESSAGE_TEXT.replace("join ","")
        await bot.join_group(link_group)
        await m.reaction(2)
    if m.type=="Group" and MESSAGE_TEXT!=None:
        if str(MESSAGE_TEXT).startswith("شارژ گروه ") and USER_GUID==owner:
            days=MESSAGE_TEXT.replace("شارژ گروه ","")
            now = int(time.time())
            see = ((((int(days)) * 24) * 60) * 60) + now
            ab_group[group_id] = {
                    "days": int(see),
                    "day_f": now,
                    "on": 1
                }
            datas[group_id]={
                    "da":False,
                    "magams":{},
                    "vi":[]
                }
            save_datas()
            save_ab_group()
            await m.reply('ربات با موفقیت شارژ شد')
        if ab_group[group_id]["days"] > int(time.time()):
            group_id=group_id
            is_admin=(await bot.user_is_admin(group_id,USER_GUID)) or (USER_GUID==owner) or (USER_GUID in datas[group_id]['vi'])
            if not (group_id in datas):
                datas[group_id]={
                    "da":False,
                    "magams":{}
                }
                save_datas()
            if 'ربات' in MESSAGE_TEXT:
                await m.reply(random.choice(list_j))
            elif MESSAGE_TEXT in ['راهنما','دستورات','/help']:
                await m.reply(help)
            if datas[group_id]['da'] or is_admin:
                if MESSAGE_TEXT.startswith('اهنگ ') or MESSAGE_TEXT.startswith('آهنگ '):
                    name_music = MESSAGE_TEXT[5:]
                    response = (find_mp3_links(name_music))[0]
                    t=True
                    try:
                        await bot.create_group_voice_chat(group_id)
                        await bot.voice_chat_player(group_id,response)
                        await m.reply(f"آهنگ {name_music} در حال پخش است ...")
                        await m.reply_music(response,f'آهنگ {name_music}')
                    except:
                        response = random.choice(find_mp3_links(name_music))
                        await bot.create_group_voice_chat(group_id)
                        await bot.voice_chat_player(group_id,response)
                        await m.reply(f"آهنگ {name_music} در حال پخش است ...")
                        await m.reply_music(response,f'آهنگ {name_music}')
                elif str(MESSAGE_TEXT).startswith('پخش ویسکال '):
                    link = MESSAGE_TEXT[11:]
                    try:
                        await bot.create_group_voice_chat(group_id)
                    except:
                        info_group=(await bot.get_group_info(group_id)).chat.group_voice_chat_id
                        await bot.join_voice_chat(group_id,info_group,None)
                    await bot.voice_chat_player(group_id, link)
                    await m.reply('ویسکال در حال پخش است ‌...')
                elif MESSAGE_TEXT=='قطع ویسکال':
                    info_group=(await bot.get_group_info(group_id)).chat.group_voice_chat_id
                    await bot.leave_group_voice_chat(group_id,info_group)
                elif MESSAGE_TEXT=="پخش ریپلای":
                    if m.reply_message_id!=None:
                        mess = await bot.get_messages_by_id(group_id,[m.reply_message_id])
                        mes = mess["messages"][0]["file_inline"]
                        await bot.download(file_inline=mes,save_as="music.mp3")
                        await bot.voice_chat_player(group_id,"music.mp3")
                        os.remove("music.mp3")
                        await m.reply("آهنگ رپیلای شده در حال پخش است ...")
                    else:
                        await m.reply("لطفا روی موزیک ریپلای کنید")
                elif MESSAGE_TEXT=='پخش رندوم':
                    mus_random=(requests.get('https://api-free.ir/api/music/').json())['result']
                    name_mus=mus_random['title']
                    link_mus=mus_random['song']
                    await bot.create_group_voice_chat(group_id)
                    await bot.voice_chat_player(group_id,link_mus)
                    await m.reply(f"آهنگ {name_mus} در حال پخش است ...")
                    await m.reply_music(link_mus,f'آهنگ {name_mus}')
                elif MESSAGE_TEXT=='ساخت کال':
                    await bot.create_group_voice_chat(group_id)
                    await m.reply('کال با موفقیت ساخته شد')
            if MESSAGE_TEXT=='لیست ویژه':
                text_vi="""کاربران ویژه
"""
                i=1
                for user in datas[group_id]['vi']:
                    text_vi+=f"""{str(i)} - [{user}]({user})
"""
                    i+=1
                if i==1:
                    text_vi+='گروه کاربر ویژه ای ندارد'
                await m.reply(text_vi)
            if MESSAGE_TEXT=='وضعیت':
                eshtrak_start = timestamp_to_shamsi(
                ab_group[group_id]["days"]
                )
                eshtrak_mandeh = timestamp_to_shamsi(
                ab_group[group_id]["day_f"]
                )
                days_esh = days_between_shamsi_dates(
                eshtrak_start, eshtrak_mandeh
                )
                e_sh = jdatetime.datetime.now()
                ee_eh = f"{e_sh.year}/{e_sh.month}/{e_sh.day}"
                esh_m = days_between_shamsi_dates(
                ee_eh, eshtrak_start
                )
                dadd="باز 🔓" if datas[group_id]['da'] else "بسته 🔒"
                await m.reply(
                                        f"""وضعیت 🔐 :

حالت اشتراک » معمولی

تاریخ خریداری اشتراک » {eshtrak_mandeh} 🕒

مانده به اتمام اشتراک » {str(esh_m)} ⌛

روز های اشتراک » {days_esh} ⏳

تاریخ اتمام اشتراک » {eshtrak_start} 🕞

تاریخ امروز » {ee_eh} 🕰

دسترسی عمومی » {dadd} """
                                    )
            if MESSAGE_TEXT=='دسترسی عموم باز' and is_admin:
                datas[group_id]={
                    "da":True
                }
                save_datas()
                await m.reply("دسترسی برای عموم با موفقیت باز شد")
            if MESSAGE_TEXT in ['دسترسی عموم بسته','دسترسی عموم قفل'] and is_admin:
                datas[group_id]={
                    "da":False
                }
                save_datas()
                await m.reply("دسترسی برای عموم با موفقیت بسته/قفل شد")
            elif MESSAGE_TEXT in ['گویدم','گوید من','گوید','گویدش','گوید گروه','گوید گپ','شناسه گوید']:
                guid_group=group_id
                guid_user=USER_GUID
                guid_replyed= m.reply_message_id
                if guid_replyed!=None:
                    reply = await m.get_reply_message()
                    reply_guid = reply.author_object_guid
                text_guid=f"""📄 گوید شما : `{guid_user}`
📄 گوید گروه : `{guid_group}`
📄 گوید کاربر ریپلای شده : `{reply_guid if guid_replyed!=None else "روی کاربری ریپلای نشده است"}`"""
                await m.reply(text_guid)
            elif str(MESSAGE_TEXT).startswith('گوید @'):
                id_user=MESSAGE_TEXT[6:]
                try:
                    guid_user=(await bot.get_object_by_username(id_user))["user"]["user_guid"]
                    await m.reply(f"📄 گوید کاربر : `{guid_user}`")
                except:
                    await m.reply('حطایی رخ داده است')
            elif MESSAGE_TEXT in ['مقامم','مقام']:
                ad=await bot.user_is_admin(group_id,USER_GUID)
                if USER_GUID==owner:
                    magam='سازنده'
                elif ad:
                    magam='ادمین گروه'
                elif USER_GUID in datas[group_id]['vi']:
                    magam='کاربر ویژه'
                else:
                    magam='کاربر عادی'
                await m.reply(magam)
            elif MESSAGE_TEXT=='ویژه':
                if is_admin:
                    guid_replyed= m.reply_message_id
                    if guid_replyed!=None:
                        reply = await m.get_reply_message()
                        reply_guid = reply.author_object_guid
                        datas[group_id]['vi'].append(reply_guid)
                        save_datas()
                        await m.reply('کاربر با موفقیت ویژه شد')
                    else:
                        await m.reply('لطفا رپیلای کنید')
                else:
                    await m.reply('شما ادمین نمیباشید')
            elif MESSAGE_TEXT=='حذف ویژه':
                if (await bot.user_is_admin(group_id,USER_GUID)) or (USER_GUID==owner):
                    guid_replyed= m.reply_message_id
                    if guid_replyed!=None:
                        reply = await m.get_reply_message()
                        reply_guid = reply.author_object_guid
                        try:
                            datas[group_id]['vi'].remove(reply_guid)
                            save_datas()
                            await m.reply('کاربر با موفقیت از لیست ویژه حذف شد')
                        except:
                            await m.reply('کاربر عضو لیست ویژه نمیباشد')
                    else:
                        await m.reply('لطفا رپیلای کنید')
                else:
                    await m.reply('برای این دستور باید ادمین باشید')
            elif MESSAGE_TEXT in ['ورژن ربات','ورژن','version','__version__','version robot','ورژن بات']:
                await m.reply(f"ورژن ربات : {__version__}")
            elif MESSAGE_TEXT=='خاموش کلی' and USER_GUID==owner:
                exit()
        else:
            await bot.send_message(group_id,"اشتراک ربات تمام شده است . جهت خرید : @O_and_ONE_01")
            await bot.leave_group(group_id)

        # except:
        #     await m.reply('خطایی رخ داده است !')
        #     await bot.send_message(owner,str(format_exc()))

bot.run()
